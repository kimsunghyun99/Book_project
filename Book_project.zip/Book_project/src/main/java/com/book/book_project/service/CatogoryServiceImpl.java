package com.book.book_project.service;

import org.springframework.stereotype.Service;

@Service
public class CatogoryServiceImpl implements CategoryService {
}
