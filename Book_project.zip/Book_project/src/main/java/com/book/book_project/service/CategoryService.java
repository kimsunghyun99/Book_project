package com.book.book_project.service;

import org.springframework.stereotype.Service;

@Service
public interface CategoryService {
}
