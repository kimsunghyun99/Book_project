언어: Java, Javascript, html, css 
클라우드 : AWS
운영 체제 : ubuntu 22.04
도메인 : 3-Tier: 웹서버 :Apache HTTP Server: WAS : Apache Tomcat 10(Spring Boot 내장)
DBMS : RDS 
인증 : Form 로그인 : OAuth2
배포: Docker/Kubernets
• 환경: MySQL,SpringBoot/JPA,Security Intelllij 
